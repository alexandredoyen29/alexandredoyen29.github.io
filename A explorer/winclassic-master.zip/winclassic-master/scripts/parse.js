// Read from local file: <http://www.html5rocks.com/en/tutorials/file/dndfiles/>
